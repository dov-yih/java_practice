package animal;

public class Fish {
    public Fish(){

    }

}
