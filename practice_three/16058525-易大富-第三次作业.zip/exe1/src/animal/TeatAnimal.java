package animal;

public class TeatAnimal {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		Fish d = new Fish();
//		Cat c = new Cat("Fluffy");
//		Animal a = new Fish();
//		Animal e = new Spider();
//		Pet p = new Cat();
//	}

}
